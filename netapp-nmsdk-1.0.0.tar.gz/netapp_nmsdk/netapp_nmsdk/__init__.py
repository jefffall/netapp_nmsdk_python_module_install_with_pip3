"""
netapp_nmsdk.
An example python library.
"""

__version__ = "1.0.0"
__author__ = 'Netapp'
__credits__ = 'Netapp'
